"""Verify the public No.65 kit; Python standard library, no network access."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
expected = {}
for line in (root / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    digest, name = line.split('  ', 1)
    path = Path(name)
    if path.is_absolute() or '..' in path.parts:
        raise SystemExit('Unsafe manifest path')
    expected[name] = digest
actual = {str(p.relative_to(root)).replace('\\', '/') for p in root.rglob('*')
          if p.is_file() and p.name != 'SHA256SUMS.txt' and '__pycache__' not in p.parts
          and p.suffix not in {'.pyc', '.exe'} and p.name != 'no65_check'}
if actual != set(expected):
    raise SystemExit('Inventory mismatch: ' + repr(actual ^ set(expected)))
for name, digest in expected.items():
    if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest:
        raise SystemExit('SHA256 mismatch: ' + name)
frozen = json.loads((root / 'FROZEN_SOURCE_SHA256.json').read_text(encoding='utf-8'))
for name, digest in frozen.items():
    if expected.get(name) != digest:
        raise SystemExit('Frozen source mismatch: ' + name)
print(f'NO65 PUBLIC KIT PASS: {len(expected)} files; {len(frozen)} frozen sources unchanged')
