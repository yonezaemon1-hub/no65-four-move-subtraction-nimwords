"""Finite structural regression only. Universal Lemmas A/C are proved in markdown.

Run with `python -B -I code/verify_lemmas_ac_v11.py`.
"""
from __future__ import annotations


def base_h(a: int, n: int) -> int:
    k = (a - 1) // 2
    d = 4 * a + 2
    L = k * d
    if n >= L:
        return n % 2
    i, t = divmod(n, d)
    u = a - 2 * i
    if t < u:
        return 0
    if a <= t < a + u:
        return 1
    if 2 * a + 1 <= t < 2 * a + u:
        return 2
    if 3 * a + 1 <= t < 3 * a + u:
        return 3
    if t == d - 1:
        return 2
    return n % 2


def check(a: int) -> tuple[int, int]:
    k = (a - 1) // 2
    d = 4 * a + 2
    L = k * d
    special = { -2*a-1: 2, -2*a: 2, -a-1: 3, -a: 3, -1: 2 }
    for x in range(-3*a+1, 2*a+1):
        expected = special.get(x, x % 2)
        actual = base_h(a, L + x)
        if actual != expected:
            raise RuntimeError(f'A FAIL a={a} x={x}, actual={actual}, expected={expected}')

    e2 = {}
    e3 = {}
    for i in range(k):
        for q in range(k-i):
            e2[i*d+1+2*q] = (i, q)
            e3[i*d+a+1+2*q] = (i, q)
    moves = (a, 2*a+1, 3*a)
    for v, (i,q) in e3.items():
        sources = [(s, v-s) for s in moves if v-s in e2]
        if sources != [(a, i*d+1+2*q)]:
            raise RuntimeError(f'C E2->E3 FAIL a={a}, (i,q)={(i,q)}, sources={sources}')
    for u, (i,q) in e2.items():
        sources = [(s, u-s) for s in moves if u-s in e3]
        wanted = [] if i == 0 else [(3*a, (i-1)*d+a+1+2*(q+1))]
        if sources != wanted:
            raise RuntimeError(f'C E3->E2 FAIL a={a}, (i,q)={(i,q)}, sources={sources}, wanted={wanted}')

    # Distinct small-move offsets of one parity cannot both be in same E set.
    for E in (e2, e3):
        for j in range(3*a, L + 3*a):
            hits = sum(j-s in E for s in moves)
            if hits > 1:
                raise RuntimeError(f'C SEPARATION FAIL a={a}, j={j}, hits={hits}')
    return len(e2), len(e3)


def main():
    pairs = 0
    for a in list(range(3, 202, 2)) + [301, 401]:
        e2_count, e3_count = check(a)
        k = (a - 1) // 2
        expected_count = k * (k+1) // 2
        if e2_count != expected_count or e3_count != expected_count:
            raise RuntimeError(f'COUNT FAIL a={a}')
        pairs += 1
    print('FINITE STRUCTURAL REGRESSION PASS:', pairs, 'odd a, A-window and complete C-edge classification')
    print('NOTE: these finite checks do not establish the universal lemma; inspect LEMMA_AC_EXPLICIT_PROOF_V11.md')

if __name__ == '__main__':
    main()
