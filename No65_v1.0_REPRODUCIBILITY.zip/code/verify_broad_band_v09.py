"""Independent Python mex test for No.65 v0.9 broad-band formula.
Finite regression only, not a proof for unbounded odd a.
"""

def grundy(subtractions, bound):
    out = bytearray(bound)
    for n in range(bound):
        reachable = {out[n-s] for s in subtractions if s <= n}
        v = 0
        while v in reachable:
            v += 1
        out[n] = v
    return out


def closed_extension(a, c, n, three):
    if n < c:
        return three[n]
    k = (a-1)//2
    d = 4*a+2
    L = k*d
    c0 = L+3*a
    m = (c0-c)//2
    if m<=k:
        r = m
        first4 = False
    elif m<=2*k:
        r = m-k
        first4 = True
    else:
        r = m-a
        first4 = False

    j=n-c
    i, t = divmod(j,d)
    if i<k:
        # The two sparse triangular sets, same block index i.
        if t&1 and 1<=t<=a-2*i-2:
            return 4 if first4 and i==0 and r and t==2*r-1 else (3 if r and i<r and t==2*(r-i)-1 else 2)
        if not(t&1) and a+1<=t<=2*a-2*i-2:
            return 2 if r and i<r and t==a+2*(r-i)-1 else 3
    return n&1


def run():
    count=0
    total=0
    for a in range(3,62,2):
        k=(a-1)//2
        L=k*(4*a+2)
        c0=L+3*a
        triple=grundy((a,2*a+1,3*a),c0+1)
        for c in range(L+1,c0+1,2):
            T=c+L-3*a
            bound=T+c+3*a+6
            G=grundy((a,2*a+1,3*a,c),bound)
            for n in range(bound):
                expected=closed_extension(a,c,n,triple)
                if G[n] != expected:
                    raise AssertionError((a,c,n,int(G[n]),int(expected)))
            assert G[T-1]!=(T-1)%2,(a,c,T)
            assert all(G[n]==n%2 for n in range(T,bound)),(a,c,T)
            total+=bound
            count+=1
    print(f'PYTHON BROAD BAND PASS: odd a=3..61, all odd c=L+1..L+3a, {count} pairs, {total} direct mex positions')
    print('Four-value early defects are included. Universal theorem proof requires independent review.')

if __name__=='__main__':
    run()
