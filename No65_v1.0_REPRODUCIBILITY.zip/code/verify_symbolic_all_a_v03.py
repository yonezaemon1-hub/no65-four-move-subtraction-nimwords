"""Exact symbolic verification of the proposed 3-move Grundy word.

Checks all odd a >= 3 simultaneously, via intervals affine in r=k-i and
v=i. All semilinear string boundary combinations are checked with rational
polyhedral feasibility in two dimensions; this is a *real relaxation*, so it
cannot miss an integer counterexample. No external packages required. The affine block coverage is also checked.
"""
from fractions import Fraction
from itertools import combinations
from functools import lru_cache

if not __debug__:
    raise RuntimeError("Proof assertions are disabled under python -O: run without -O")

# Linear affine integer expression in r,v: a*r + b*v + c.
R=(1,0,0); V=(0,1,0); ONE=(0,0,1); ZERO=(0,0,0)
def add(x,y): return tuple(a+b for a,b in zip(x,y))
def neg(x): return tuple(-a for a in x)
def sub(x,y): return add(x,neg(y))
def mul(x,n): return tuple(n*a for a in x)
def cn(n):return (0,0,n)
def ev(x, r, v): return x[0]*r+x[1]*v+x[2]
def par(x):
    assert x[0]%2==0 and x[1]%2==0, x
    return x[2]%2

def seg(lo,hi,val): return (lo,hi,val)
def base_segments(rshift=0,vshift=0,tail=False):
    if tail:
        a=add(mul(R,2),add(mul(V,2),cn(1)));d=add(mul(a,4),cn(2))
        return [seg(ZERO, sub(d,ONE),'par')]
    a=add(mul(R,2),add(mul(V,2),cn(1)));d=add(mul(a,4),cn(2))
    u=add(mul(R,2),cn(1))
    # prior has u+2 (r' = r+1)
    if rshift: u=add(u,cn(2*rshift))
    out=[
      seg(ZERO,sub(u,ONE),0),
      seg(u,sub(a,ONE),'par'),
      seg(a, sub(add(a,u),ONE),1),
      seg(add(a,u),mul(a,2),'par'),
      seg(add(mul(a,2),ONE),sub(add(mul(a,2),u),ONE),2),
      seg(add(mul(a,2),u),mul(a,3),'par'),
      seg(add(mul(a,3),ONE),sub(add(mul(a,3),u),ONE),3),
      seg(add(mul(a,3),u),sub(d,cn(2)),'par'),
      seg(sub(d,ONE),sub(d,ONE),2)
    ]
    return out



def assert_partition(segs, d, domain, label):
    """Universal affine coverage of [0,d-1], including empty segments.

    Domain is one of:
      first  r>=1, v=0
      middle r>=1, v>=1
      tail   r=0, v>=1
    This checks *symbolic identities*, not a finite parameter sample.
    """
    assert segs, (label, 'empty segment list')
    assert segs[0][0] == ZERO, (label, 'first lo', segs[0][0])
    assert segs[-1][1] == sub(d, ONE), (label, 'last hi', segs[-1][1], d)
    for i, (lo, hi, _) in enumerate(segs):
        # hi-lo+1 >= 0 throughout the parameter region: empty allowed.
        length = sub(add(hi, ONE), lo)
        A, B, C = length
        if domain == 'first':
            assert A >= 0 and A+C >= 0, (label,i,'negative length',length)
        elif domain == 'middle':
            assert A >= 0 and B >= 0 and A+B+C >= 0, (label,i,'negative length',length)
        elif domain == 'tail':
            assert B >= 0 and B+C >= 0, (label,i,'negative length',length)
        else:
            raise ValueError(domain)
        if i:
            # Componentwise affine equality: for all (r,v), not samples.
            assert add(segs[i-1][1], ONE) == lo, (label, i, 'GAP/OVERLAP', segs[i-1], segs[i])
    return True


def assert_all_partitions():
    """Check target and predecessor full-block partitions for all regimes."""
    for domain in ('first', 'middle', 'tail'):
        a = add(mul(R,2), add(mul(V,2),cn(1)))
        d = add(mul(a,4),cn(2))
        cur = base_segments(tail=(domain=='tail'))
        assert_partition(cur, d, domain, domain + '/target')
        # In middle/tail, each small move may reach the previous block.
        # Earlier block has run length u+2 (r is increased by one).
        if domain != 'first':
            prev = base_segments(rshift=1)
            assert_partition(prev, d, domain, domain + '/previous')
    print('COVERAGE PASS: exact affine start/end, adjacency and nonnegative lengths for first/middle/tail and predecessor blocks')
    return True

def on_predecessor(s,case):
    a=add(mul(R,2),add(mul(V,2),cn(1)));d=add(mul(a,4),cn(2))
    current=base_segments(tail=case=='tail')
    prev=base_segments(rshift=1)
    res=[]
    # same block
    for lo,hi,val in current:
        res.append(seg(add(lo,s),add(hi,s), 'flippar' if val=='par' else val))
    # previous block available
    if case!='first':
        for lo,hi,val in prev:
            res.append(seg(sub(lo,sub(d,s)),sub(hi,sub(d,s)), 'flippar' if val=='par' else val))
    else:
        res.append(seg(ZERO,sub(s,ONE),None))
    return res

# constraints: alpha*r + beta*v + gamma >= 0

def feasible(cs):
    # A nonempty polyhedron with r,v >= 0 has an extreme point.
    # Always includes r,v lower bound so no lineality.
    for ix,iy in combinations(range(len(cs)),2):
        a,b,c=cs[ix];A,B,C=cs[iy]
        det=a*B-b*A
        if det==0:continue
        r=Fraction(-c*B+b*C,det)
        v=Fraction(-a*C+c*A,det)
        if all(ev(q,r,v)>=0 for q in cs):return (r,v)
    return None

def intersect(seglist,p,basecs):
    lows=[];highs=[]
    for lo,hi,val in seglist:
        # t is forced to parity p. Adjust lower / upper to nearest p.
        lo2=add(lo,cn((p-par(lo))%2))
        hi2=sub(hi,cn((par(hi)-p)%2))
        lows.append(lo2);highs.append(hi2)
    cs=basecs[:]
    cs.extend(sub(u,l) for l in lows for u in highs)
    return feasible(cs)

def val_for(v,p):
    return p if v=='par' else 1-p if v=='flippar' else v

def mex(xs):
    i=0
    while i in xs: i+=1
    return i

def run():
  assert_all_partitions()  # Fail before recurrence checks if any block has a gap.
  all_counts=[]
  for case in ('first','middle','tail'):
    # r>=1,v=0; r>=1,v>=1; r=0,v>=1
    cs={'first':[sub(R,ONE),V, neg(V)],
        'middle':[sub(R,ONE),sub(V,ONE)],
        'tail':[R,neg(R),sub(V,ONE)]}[case]
    target=base_segments(tail=case=='tail')
    a=add(mul(R,2),add(mul(V,2),cn(1)))
    moves=(a,add(mul(a,2),ONE),mul(a,3))
    preds=[on_predecessor(s,case) for s in moves]
    checked=0;bad=[]
    for p in (0,1):
     for target_s in target:
      for s1 in preds[0]:
       if intersect([target_s,s1],p,cs) is None:continue
       for s2 in preds[1]:
        if intersect([target_s,s1,s2],p,cs) is None:continue
        for s3 in preds[2]:
         w=intersect([target_s,s1,s2,s3],p,cs)
         if w is None: continue
         checked+=1
         values=(val_for(s1[2],p),val_for(s2[2],p),val_for(s3[2],p))
         want=val_for(target_s[2],p)
         got=mex(values)
         if want!=got:
            bad.append((p,w,values,want,got,target_s,s1,s2,s3))
            if len(bad)>=5:break
        if len(bad)>=5:break
       if len(bad)>=5:break
      if len(bad)>=5:break
     if len(bad)>=5:break
    print(case, 'feasible piecewise local cases',checked, 'bad',len(bad))
    if bad:
      for x in bad:
       print('BAD',str(x)[:1500])
      return False
    all_counts.append(checked)
  print('PROOF CHECK PASS: recurrence of 3-move word for ALL odd a>=3')
  print('cases=',all_counts)
  return True
if __name__=='__main__':
    assert run()
