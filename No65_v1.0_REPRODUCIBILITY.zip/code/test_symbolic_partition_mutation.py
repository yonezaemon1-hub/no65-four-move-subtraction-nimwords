"""Adversarial no-gap regression tests for the v0.3 universal verifier."""
from pathlib import Path
import importlib.util

path = Path(__file__).with_name('verify_symbolic_all_a_v03.py')
spec = importlib.util.spec_from_file_location('no65_symbolic_v03', path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

assert mod.assert_all_partitions()
normal = mod.base_segments

def shorten_one_run(*args, **kwargs):
    segs = normal(*args, **kwargs)
    if not kwargs.get('tail', False):
        segs = list(segs)
        lo, hi, value = segs[2]  # one-run [a,a+u-1], shorten by one
        segs[2] = (lo, mod.sub(hi,mod.ONE), value)
    return segs

mod.base_segments = shorten_one_run
caught = False
try:
    mod.run()
except AssertionError as ex:
    assert 'GAP/OVERLAP' in str(ex), ('wrong assertion triggered',str(ex))
    caught = True
finally:
    mod.base_segments = normal
assert caught, 'MUTATION ESCAPED: gap in one-run was not rejected'
print('MUTATION PASS: shortening 1-run by one is rejected as a gap')
assert mod.run()
print('REGRESSION PASS: unmodified full checker succeeds')
