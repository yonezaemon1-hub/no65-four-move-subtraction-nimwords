#include <cstdint>
#include <iostream>
#include <vector>
#include <string>
#include <stdexcept>
using namespace std;
uint8_t mex4(const vector<uint8_t>& z, int n, int a, int c, bool four) {
    unsigned mask=0; int m[4]={a,2*a+1,3*a,c};
    for(int k=0;k<(four?4:3);++k)if(n>=m[k])mask|=1u<<z[n-m[k]];
    uint8_t v=0;while(mask&(1u<<v))++v;return v;
}
uint8_t formula(int a,int c,int n,bool corrections){
    int k=(a-1)/2,d=4*a+2,L=k*d;
    if(n<c)throw runtime_error("n<c");
    int j=n-c,i=j/d,t=j%d;
    if(i<k){
      if(t>=1 && t<=a-2*i-2 && (t&1)){
        if(corrections){int m=(L+3*a-c)/2;int r=(m<=k?m:(m<=2*k?m-k:m-a));if(r>0 && i<r && t==2*(r-i)-1)return (m>k && m<=2*k && i==0)?4:3;}
        return 2;
      }
      if(t>=a+1 && t<=2*a-2*i-2 && !(t&1)){
        if(corrections){int m=(L+3*a-c)/2;int r=(m<=k?m:(m<=2*k?m-k:m-a));if(r>0 && i<r && t==a+2*(r-i)-1)return 2;}
        return 3;
      }
    }
    return n&1;
}
int main(){
    long long pairs=0,positions=0;int max_a=81;
    for(int a=3;a<=max_a;a+=2){
      int k=(a-1)/2,L=k*(4*a+2),c0=L+3*a;
      for(int c=L+1;c<=c0;c+=2){
        int T=c+L-3*a,N=T+c+3*a+6;
        vector<uint8_t> z(N); for(int n=0;n<N;n++)z[n]=mex4(z,n,a,c,true);
        long long dif=0; int m=(c0-c)/2;int r=(m<=k?m:(m<=2*k?m-k:m-a));
        for(int n=c;n<N;n++){
          uint8_t want=formula(a,c,n,true);
          if(z[n]!=want){cerr<<"FAIL a="<<a<<" c="<<c<<" n="<<n<<" got="<<(int)z[n]<<" want="<<(int)want<<"\n";return 1;}
          dif+=(z[n]!=formula(a,c,n,false));
        }
        if(dif!=2*r){cerr<<"diffcount FAIL "<<a<<" "<<c<<" "<<dif<<" expected "<<2*r<<"\n";return 1;}
        if(z[T-1]==((T-1)&1)){cerr<<"PREPERIOD FAIL "<<a<<" "<<c<<" T="<<T<<"\n";return 1;}
        for(int n=T;n<N;n++)if(z[n]!=(n&1)){cerr<<"TAIL FAIL "<<a<<" "<<c<<" n="<<n<<"\n";return 1;}
        pairs++; positions+=N;
      }
    }
    cout<<"ALL-EARLY-C RANGE PASS a=3.."<<max_a<<" odd, c every odd L+1..L+3a, pairs="<<pairs<<", mex positions="<<positions<<"\n";
    for(int a:{101,151,201,301,501,801}){
      int k=(a-1)/2,L=k*(4*a+2),c0=L+3*a;
      for(int m:{0,1,2,3,k,k+1,2*k+1,3*k+1}){
        int c=c0-2*m;if(c<L+1)continue;
        int T=c+L-3*a,N=T+c+3*a+6;
        vector<uint8_t> z(N);for(int n=0;n<N;n++)z[n]=mex4(z,n,a,c,true);
        for(int n=c;n<N;n++)if(z[n]!=formula(a,c,n,true)){cerr<<"LARGE FAIL a="<<a<<" m="<<m<<" n="<<n<<"\n";return 1;}
        if(z[T-1]==((T-1)&1)){cerr<<"LARGE MIN FAIL "<<a<<" "<<m<<"\n";return 1;}
        cout<<"Large a="<<a<<", m="<<m<<", c="<<c<<", N="<<N<<" PASS\n";
        positions+=N;pairs++;
      }
    }
    cout<<"FINAL ALL PASS: "<<pairs<<" pairs, "<<positions<<" mex positions\n";
}
