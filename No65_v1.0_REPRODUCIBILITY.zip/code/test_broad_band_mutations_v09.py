"""Three deliberate corruptions must be detected by direct mex comparison."""
from pathlib import Path
from runpy import run_path
_tools = run_path(str(Path(__file__).with_name("verify_broad_band_v09.py")))
grundy = _tools["grundy"]
closed_extension = _tools["closed_extension"]

def ensure_rejected(a,c,position,bad_value):
    k=(a-1)//2; L=k*(4*a+2)
    h=grundy((a,2*a+1,3*a),c)
    G=grundy((a,2*a+1,3*a,c),c+L+100)
    actual=G[position]
    predicted=closed_extension(a,c,position,h)
    if actual!=predicted or actual==bad_value:
        raise AssertionError((a,c,position,actual,predicted,bad_value))
    print('MUTANT REJECTED:', a,c,position,'actual',actual,'bad',bad_value)

def run():
    # Underreport 4 as 3, omit the second diagonal E2 change, and omit E3 partner.
    ensure_rejected(7,103,104,3)
    ensure_rejected(7,107,138,2)  # c+31 is the later E2 point (3 not 2)
    ensure_rejected(7,109,117,3)  # c+8 is the altered E3 partner (2 not 3)
    print('V09 MUTATION PASS: three deliberately wrong predictions caught')
if __name__=='__main__':run()
