# No.65 v1.0 reproducibility kit

Ryutaro Yonezu - Independent Researcher. 12 November 2026.
Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.

This kit accompanies *Exact Nim-Words and Sharp Preperiods in an Infinite
Two-Parameter Four-Move Subtraction Family*, preprint v1.0.

The theorem concerns odd a>=3 and odd c>=L+1, L=(a-1)(2a+1), with moves
{a,2a+1,3a,c}. It includes the three-phase corrections in L+1<=c<=L+3a,
including a middle-band seed of 4. The least preperiod is c+L-3a and the
least eventual period is 2. The uncorrected old word is asserted only for
c>=L+3a. No optimal lower cutoff in c is claimed.

## Status and limits

- Independent AI-assisted and SMT verification within the documented scope
- Windows PowerShell 5.1 reproduction PASS (author-run)
- NOVELTY INCONCLUSIVE
- REFERENCES PARTIAL
- Not peer-reviewed
- All rights reserved

SMT conclusions depend on encoding faithfulness and solver correctness.
There is no human peer review, proof-assistant formalization, second-solver
confirmation, or worldwide novelty certificate. Ho's base word and Zhang's
bounded period-two observations are prior work. Flammenkamp's expanded 1997
book remains unchecked. See the matching manuscript for the exact comparison.

## Files and integrity

`code/` contains six byte-identical supplied v0.11 computational sources.
`smt/` contains four byte-identical supplemental computational sources/files.
`FROZEN_SOURCE_SHA256.json` records their original SHA256 values.
`expected/` contains clean output from actual Linux re-execution during
publication preparation. No private original ZIP or raw Windows log is included.

Run `python -B verify_repro.py` in the extracted root. It verifies the complete
relative-path manifest and checks the frozen-source hashes. The ZIP is a new
public selection; it is not the integrated private research archive.

## Reproduction

Python 3.10+ is sufficient for the standard-library tests. Work in a writable
folder; the mutation checks import their neighboring module, so do not add
Python's isolated `-I` flag to those two commands.

```text
python -B code/verify_symbolic_all_a_v03.py
python -B code/test_symbolic_partition_mutation.py
python -B code/verify_lemmas_ac_v11.py
python -B code/verify_broad_band_v09.py
python -B code/test_broad_band_mutations_v09.py
python -B smt/run_smt.py
python -B smt/audit_direct_nim.py
```

`run_smt.py` needs the free z3-solver Python package or an installed system
libz3. On the author's Windows system the supplied report states package
z3-solver 5.4.1.0, displaying Z3 5.4.1. Publication preparation instead used
system Z3 4.13.3 through the runner's shared-library fallback. These are
distinct environments, not a second-solver verification. No paid API is used.

For the supplied C++17 regression:

```text
g++ -std=c++17 -O2 -Wall -Wextra -Werror code/verify_broad_band_v09.cpp -o no65_check
./no65_check
```

On Windows PowerShell use `./no65_check.exe` after compilation. A C++17
compiler must already be installed or installed separately. This kit does
not install software, contact services, or require an API key.

## Expected results and what they establish

| Check | Result | Scope |
| --- | --- | --- |
| Base SMT control | UNSAT | All encoded odd a>=3 and base indices |
| Four-move SMT control | UNSAT | All encoded odd a>=3, odd c>=L+1, post-c offsets |
| Three intentional SMT mutations | SAT each | Nonvacuity/negative controls |
| Supplemental Python direct mex | 790 pairs / 2,677,220 generated and compared positions | odd a=3..41; odd c=[L+1,L+3a+13] |
| Broad-band Python | 1,455 pairs / 16,739,670 generated positions | odd a=3..61; full boundary band |
| C++17 | 2,588 pairs / 101,872,020 generated positions | band through a=81 plus 48 selected large pairs |
| A/C structural regression | 102 odd a | Finite window and edge checks |
| Exact-rational base certificate | 12/27/16 cases, zero bad | Universal affine reduction, with coverage guards |

The broad-band Python compares all positions, using a directly generated
three-move prefix before c. C++ generates the entire mex prefix but compares
the closed extension from n=c onward; its printed position total counts
generated mex values, not separate closed-form prefix comparisons. The
supplemental independent Python compares the explicit base and corrected
formula at every generated position. Do not add these totals to claim
distinct tested positions; their parameter ranges overlap.

Finite sweeps do not establish an infinite theorem or historical originality.
The manuscript explains the universal SMT reduction and analytic A-D proof.
The historical candidate/HOLD wording printed by unchanged scripts is kept
as source history and does not alter the public v1.0 status.

## Windows evidence

The supplied sanitized v0.12 record ties the author's v0.11 run to the exact
frozen v0.11 ZIP and reports the structural, symbolic, Python and C++ PASS
results above. It was author-run on Windows PowerShell 5.1, not witnessed.
The separate Windows SMT author report is summarized above; its raw log is
not supplied in this public kit. Current Linux reruns match the stated
numerical results. The publication editor performed no Windows execution.

## Source provenance

- Private v0.12 source ZIP SHA256: 20f19be1a96b595a4a724bedd21f2b7d4f59176032712cd1337b13394a3aff2a
- Embedded original v0.11 ZIP SHA256: 4a6aaf6259812f6a43b2fc00c5d1417f38a09f5f8ba4ac40e66b2aff3bef72ab
- Supplemental private SMT ZIP SHA256: 9c9f51c92ae063ed9a65cf5d96306f33ee92bb0e5c2941ccd6743c8dfb2a6c9e

All 19 extracted v0.11 files matched the embedded archive; its 18-entry
manifest and the 25-entry v0.12 manifest passed. The supplemental 7-entry
manifest passed. Only the selected computational files are distributed here,
unchanged. New publication documents and packaging do not overwrite any
private frozen mathematics, source code, or historical audit record.
