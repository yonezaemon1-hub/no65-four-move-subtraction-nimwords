
(set-option :timeout 120000)
(declare-const k Int)
(declare-const i Int)
(declare-const tp Int)
(define-fun a () Int (+ (* 2 k) 1))
(define-fun d () Int (+ (* 4 a) 2))
(define-fun h ((I Int) (t Int)) Int
 (let ((u (- a (* 2 I))))
  (ite (>= I k) (mod t 2)
   (ite (and (<= 0 t) (< t u)) 0
    (ite (and (<= a t) (< t (+ a u))) 1
     (ite (and (<= (+ (* 2 a) 1) t) (< t (+ (* 2 a) u))) 2
      (ite (and (<= (+ (* 3 a) 1) t) (< t (+ (* 3 a) u))) 3
       (ite (= t (- d 1)) 2 (mod t 2)))))))))
(define-fun legal ((s Int)) Bool (or (> i 0) (>= tp s)))
(define-fun src ((s Int)) Int
 (ite (>= tp s) (h i (- tp s)) (h (- i 1) (+ (- tp s) d))))
(define-fun val () Int (h i tp))
(define-fun s1 () Int a)
(define-fun s2 () Int (+ (* 2 a) 1))
(define-fun s3 () Int (* 3 a))
(define-fun includes ((w Int)) Bool
 (or (and (legal s1) (= (src s1) w))
     (and (legal s2) (= (src s2) w))
     (and (legal s3) (= (src s3) w))))
(assert (>= k 1))
(assert (>= i 0))
(assert (>= tp 0))
(assert (< tp d))
; Negation of the mex recursion: either candidate is present, or smaller value is missing.
(assert (or (includes val)
    (and (> val 0) (not (includes 0)))
    (and (> val 1) (not (includes 1)))
    (and (> val 2) (not (includes 2)))
    (and (> val 3) (not (includes 3)))))
(check-sat)
