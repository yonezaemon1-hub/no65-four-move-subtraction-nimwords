"""No65 independent machine-audit runner; prefers z3-solver, falls back to OS libz3.
No network, no package installation, no access to personal files.
"""
from pathlib import Path
import ctypes
from ctypes.util import find_library

ROOT=Path(__file__).resolve().parent

def execute_smt(src):
    # Most portable on Windows: `python -m pip install z3-solver`
    try:
        import z3
    except ImportError:
        z3=None
    if z3 is not None:
        s=z3.Solver()
        s.set(timeout=120000)
        s.from_string(src.replace('(check-sat)','').replace('(get-model)',''))
        return str(s.check())
    libname=find_library('z3')
    for name in [libname,'libz3.so.4','libz3.so','libz3.dll','z3.dll']:
        if not name: continue
        try: zz=ctypes.CDLL(name);break
        except OSError: continue
    else:
        raise RuntimeError('Z3 library unavailable. Install free z3-solver: python -m pip install z3-solver')
    zz.Z3_mk_config.restype=ctypes.c_void_p
    zz.Z3_mk_context.argtypes=[ctypes.c_void_p]
    zz.Z3_mk_context.restype=ctypes.c_void_p
    zz.Z3_eval_smtlib2_string.argtypes=[ctypes.c_void_p,ctypes.c_char_p]
    zz.Z3_eval_smtlib2_string.restype=ctypes.c_char_p
    zz.Z3_del_context.argtypes=[ctypes.c_void_p]
    config=zz.Z3_mk_config()
    ctx=zz.Z3_mk_context(config)
    try:
        answer=zz.Z3_eval_smtlib2_string(ctx,src.encode('utf-8'))
        return answer.decode('utf-8').strip() if answer else '<no output>'
    finally:
        zz.Z3_del_context(ctx)

def main():
    base=(ROOT/'LEMMA2_UNIVERSAL_MEX.smt2').read_text(encoding='utf-8')
    four=(ROOT/'FOURMOVE_UNIVERSAL_MEX.smt2').read_text(encoding='utf-8')
    cases={
        'LEMMA2_CONTROL': (base,'unsat'),
        'FOURMOVE_CONTROL': (four,'unsat'),
        'MUTATION_BASE_LAST_2_TO_1':(base.replace('(ite (= t (- d 1)) 2 (mod t 2))', '(ite (= t (- d 1)) 1 (mod t 2))'),'sat'),
        'MUTATION_MIDDLE_SEED_4_TO_3':(four.replace('(define-fun seed () Int (ite bB 4 3))','(define-fun seed () Int 3)'),'sat'),
        'MUTATION_CHAIN_E3_2_TO_3':(four.replace('(ite e3 (ite cV 2 3)', '(ite e3 (ite cV 3 3)'),'sat'),
    }
    for title,(src,expected) in cases.items():
        result=execute_smt(src)
        print(title,':',result,'(expected:',expected+')',flush=True)
        assert result==expected,(title,result,expected)
    print('INDEPENDENT SMT AUDIT PASS; all 5 checks match expected.')

if __name__=='__main__':main()
