"""Independent finite direct-mex regression of No.65 four-move closed word."""

def h(a, n):
    k=(a-1)//2
    d=4*a+2
    L=k*d
    if n>=L: return n%2
    i,t=divmod(n,d)
    u=a-2*i
    if 0<=t<u: return 0
    if a<=t<a+u: return 1
    if 2*a+1<=t<2*a+u: return 2
    if 3*a+1<=t<3*a+u: return 3
    if t==d-1: return 2
    return n%2

def conjectured(a,c,n):
    if n<c: return h(a,n)
    k=(a-1)//2
    d=4*a+2
    L=k*d
    c0=L+3*a
    j=n-c
    i,t=divmod(j,d)
    if i<k and t%2==1 and 1<=t<=a-2-2*i:
        value=2
    elif i<k and t%2==0 and a+1<=t<=2*a-2-2*i:
        value=3
    else:
        return n%2
    if c<=c0:
        m=(c0-c)//2
        if 0<=m<=k: r,seed=m,3
        elif k+1<=m<=2*k: r,seed=m-k,4
        elif 2*k+1<=m<=3*k+1: r,seed=m-(2*k+1),3
        else: r,seed=0,3
        if i<r:
            if t==2*(r-i)-1: return seed if i==0 else 3
            if t==a+2*(r-i)-1: return 2
    return value

def nim(a,c,lim):
    moves=(a,2*a+1,3*a,c)
    out=[]
    for n in range(lim):
        vals=set(out[n-s] for s in moves if n>=s)
        x=0
        while x in vals: x+=1
        out.append(x)
    return out

def main():
    pairs=positions=0
    for a in range(3,42,2):
        k=(a-1)//2
        L=k*(4*a+2)
        for c in range(L+1,L+3*a+14,2):
            lim=c+L+41
            found=nim(a,c,lim)
            for n,val in enumerate(found):
                exp=conjectured(a,c,n)
                if val!=exp:
                    raise AssertionError((a,c,n,val,exp))
            ell=c+L-3*a
            if found[ell-1]==(ell-1)%2: raise AssertionError(('last nonparity',a,c,ell))
            if any(found[n]!=n%2 for n in range(ell,lim)):
                raise AssertionError(('tail',a,c,ell))
            pairs+=1
            positions+=lim
    print(f'DIRECT_MEX_PASS pairs={pairs} positions={positions} a=3..41 odd c=[L+1,L+3a+13] odd; no mismatches')
if __name__=='__main__':main()
