
(set-option :timeout 90000)
(set-option :produce-models true)
(declare-const k Int)
(declare-const tau Int)
(declare-const m Int)
(declare-const i Int)
(declare-const tp Int)
(define-fun a () Int (+ (* 2 k) 1))
(define-fun d () Int (+ (* 4 a) 2))
(define-fun T0 () Int (+ (* 2 tau) 1))
(define-fun K () Int (+ k m))
(define-fun bA () Bool (and (= m 0) (>= T0 (+ (* 2 a) 1)) (<= T0 (- (* 3 a) 2))))
(define-fun bB () Bool (and (= m 0) (>= T0 (+ a 2)) (<= T0 (- (* 2 a) 1))))
(define-fun bC () Bool (and (= m 0) (<= T0 (- a 2))))
(define-fun r () Int (ite bA (div (- (* 3 a) T0) 2) (ite bB (div (- (+ (* 2 a) 1) T0) 2) (ite bC (div (- a T0) 2) 0))))
(define-fun seed () Int (ite bB 4 3))

(define-fun hb ((I Int) (t Int)) Int
 (let ((u (- a (* 2 I))))
  (ite (>= I k) (mod t 2)
  (ite (and (>= t 0) (< t u)) 0
  (ite (and (>= t a) (< t (+ a u))) 1
  (ite (and (>= t (+ (* 2 a) 1)) (< t (+ (* 2 a) u))) 2
  (ite (and (>= t (+ (* 3 a) 1)) (< t (+ (* 3 a) u))) 3
  (ite (= t (- d 1)) 2 (mod t 2)))))))))

(define-fun Hc ((x Int)) Int (ite (< x 0) (hb (- K 1) (+ d x)) (hb K x)))
(define-fun G ((I Int) (t Int)) Int
 (let ((e2 (and (< I k) (= (mod t 2) 1) (>= t 1) (<= t (- (- a 2) (* 2 I)))))
       (e3 (and (< I k) (= (mod t 2) 0) (>= t (+ a 1)) (<= t (- (- (* 2 a) 2) (* 2 I)))))
       (cU (and (< I r) (= t (- (* 2 (- r I)) 1))))
       (cV (and (< I r) (= t (- (+ a (* 2 (- r I))) 1)))))
  (ite e2 (ite cU (ite (= I 0) seed 3) 2)
   (ite e3 (ite cV 2 3) (mod (+ T0 t) 2)))))

(define-fun ps ((s Int)) Int
 (ite (>= (- tp s) 0) (G i (- tp s))
  (ite (>= i 1) (G (- i 1) (+ (- tp s) d)) (Hc (+ T0 (- tp s))))))

(define-fun lv () Int
 (ite (or (< i K) (and (= i K) (< tp T0))) (hb i tp)
  (ite (>= tp T0) (G (- i K) (- tp T0)) (G (- (- i K) 1) (+ (- tp T0) d)))))
(define-fun v () Int (G i tp))
(define-fun p1 () Int (ps a))
(define-fun p2 () Int (ps (+ (* 2 a) 1)))
(define-fun p3 () Int (ps (* 3 a)))
(assert (>= k 1))
(assert (>= tau 0))
(assert (<= T0 (- d 1)))
(assert (>= m 0))
(assert (>= i 0))
(assert (>= tp 0))
(assert (< tp d))
; Try to find a counterexample to the mex recurrence.
(assert
 (or (= v lv) (= v p1) (= v p2) (= v p3)
     (and (> v 0) (not (or (= 0 lv) (= 0 p1) (= 0 p2) (= 0 p3))))
     (and (> v 1) (not (or (= 1 lv) (= 1 p1) (= 1 p2) (= 1 p3))))
     (and (> v 2) (not (or (= 2 lv) (= 2 p1) (= 2 p2) (= 2 p3))))
     (and (> v 3) (not (or (= 3 lv) (= 3 p1) (= 3 p2) (= 3 p3))))
     (and (> v 4) (not (or (= 4 lv) (= 4 p1) (= 4 p2) (= 4 p3))))))
(check-sat)
